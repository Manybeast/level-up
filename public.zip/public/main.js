/**
 * Created by IlyaLitvinov on 20.11.15.
 *
 */

$(document).ready(function () {
    var form = new RegistrationForm();
});
